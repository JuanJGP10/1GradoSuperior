package programacion.tema9.Ajedrez;

/**
 * Clase de enumeracion ColorPieza donde listaremos los colores de las piezas
 */
public enum ColorPieza {
    BLANCO, NEGRO
}
